const inputsValueObj = () => {
  const inputs = {
    title: "",
    subtitle: "",
    phone: "",
    email: "",
    description: "",
    web: "",
    url: "",
    alt: "",
    state: "",
    country: "",
    city: "",
    street: "",
    houseNumber: "",
    zip: "",
  };
  return inputs;
};
export { inputsValueObj };
