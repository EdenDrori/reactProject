const ROUTES = {
  HOME: "/",
  REGISTER: "/register",
  LOGIN: "/login",
  EDITCARD: "/editcard",
  CREATECARD: "/createcard",
  MYCARD: "/mycard",
  FAVORITE: "/favorite",
  PROFILE: "/profile",
  LOGOUT: "/logout",
  USERS: "/users",
  EDITUSERS: "/editusers",
  EDITPROFILE: "/editprofile",
  ABOUT: "/about",
};
export default ROUTES;
