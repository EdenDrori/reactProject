import axios from "axios";
import { Navigate } from "react-router-dom";
import { toast } from "react-toastify";
import ROUTES from "../../routes/ROUTES";

const handleUpdateChangesClick = async (inputsValue, _id) => {
  try {
    const { data } = await axios.put("/cards/" + _id, {
      title: inputsValue.title,
      subtitle: inputsValue.subtitle,
      description: inputsValue.description,
      phone: inputsValue.phone,
      email: inputsValue.email,
      web: inputsValue.web,
      image: {
        url: inputsValue.url,
        alt: inputsValue.alt,
      },
      address: {
        state: inputsValue.state,
        country: inputsValue.country,
        city: inputsValue.city,
        street: inputsValue.street,
        houseNumber: inputsValue.houseNumber,
        zip: +inputsValue.zip,
      },
    });

    toast("Your card has been edit succssefully", {
      position: "top-center",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
    Navigate(ROUTES.HOME);
  } catch (err) {
    console.log("err", err);
    toast("Somthing is missing... try again", {
      position: "top-center",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  }
};

export default handleUpdateChangesClick;
